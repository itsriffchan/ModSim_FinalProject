function [x_m, y_m] = geo_utm51n_forward(lon_deg, lat_deg)
%GEO_UTM51N_FORWARD  WGS84 Transverse Mercator, UTM zone 51N (EPSG:32651).
%   Snyder (1987) USGS PP 1395 series, accurate to well under 0.05 m in NCR.
%   Inputs may be arrays. Units: degrees in, metres out.

    a  = 6378137.0;
    f  = 1 / 298.257223563;
    k0 = 0.9996;
    FE = 500000.0;
    FN = 0.0;
    lam0 = deg2rad(123.0);

    phi = deg2rad(lat_deg);
    lam = deg2rad(lon_deg);
    e2  = f * (2 - f);
    ep2 = e2 / (1 - e2);
    N   = a ./ sqrt(1 - e2 .* sin(phi).^2);
    T   = tan(phi).^2;
    C   = ep2 .* cos(phi).^2;
    A   = (lam - lam0) .* cos(phi);
    e4  = e2^2;
    e6  = e2^3;
    M   = a .* ((1 - e2/4 - 3*e4/64 - 5*e6/256) .* phi ...
        - (3*e2/8 + 3*e4/32 + 45*e6/1024) .* sin(2*phi) ...
        + (15*e4/256 + 45*e6/1024) .* sin(4*phi) ...
        - (35*e6/3072) .* sin(6*phi));
    x_m = FE + k0 .* N .* (A + (1-T+C).*A.^3/6 + (5-18*T+T.^2+72*C-58*ep2).*A.^5/120);
    y_m = FN + k0 .* (M + N.*tan(phi).*(A.^2/2 + (5-T+9*C+4*C.^2).*A.^4/24 ...
        + (61-58*T+T.^2+600*C-330*ep2).*A.^6/720));
end
